<?php
if(isset($_POST["id"]))
{
	$id=$_POST["id"];
	if(!empty($id) && is_numeric($id))
	{
	   require_once"connexion.php";
       $conn=se_connecter();
       $query="delete from event where id=$id";
       $conn->exec($query);
       header("location:gestionEvents.php");
	}
}
?>